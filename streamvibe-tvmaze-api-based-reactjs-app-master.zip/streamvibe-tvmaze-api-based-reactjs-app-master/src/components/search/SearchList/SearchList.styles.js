import styled from 'styled-components';

export const SearchListWrapper = styled.div``;