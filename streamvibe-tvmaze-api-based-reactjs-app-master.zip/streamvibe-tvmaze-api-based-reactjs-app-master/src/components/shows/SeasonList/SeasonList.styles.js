import styled from 'styled-components';

export const SeasonListWrapper = styled.div``;