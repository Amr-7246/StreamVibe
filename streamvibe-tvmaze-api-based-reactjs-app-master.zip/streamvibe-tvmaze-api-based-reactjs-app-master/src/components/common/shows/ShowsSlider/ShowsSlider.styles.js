import styled from 'styled-components';

export const ShowsSliderWrapper = styled.section`
    padding: 40px 0;

    .slider-wrapper{
        margin-top: 40px;
    }
`;