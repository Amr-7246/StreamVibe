
const NotDataFound = () => {
  return (
    <div>
      
    </div>
  )
}

export default NotDataFound
