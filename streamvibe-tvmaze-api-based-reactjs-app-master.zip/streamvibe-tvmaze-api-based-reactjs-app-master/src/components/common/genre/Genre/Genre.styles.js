import styled from "styled-components";

export const GenreWrapper = styled.div`
  position: relative;
`;
