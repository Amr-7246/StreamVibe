const routeConstants = {
    HOME: "/",
    SHOWS: "/shows",
    SEARCH: "/search"
}

export default routeConstants;