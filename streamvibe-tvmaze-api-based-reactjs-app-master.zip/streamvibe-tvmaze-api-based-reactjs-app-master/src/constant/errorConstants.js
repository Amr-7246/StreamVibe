const errorConstants = {
  ERR_404: "ERR_404",
  ERR_429: "ERR_429",
};

export default errorConstants;
