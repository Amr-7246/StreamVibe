export const HIGH_RATED_SHOWS = 'HIGH_RATED_SHOWS';
export const NEW_SHOWS = 'NEW_SHOWS';   
export const DEFAULT_SHOWS = "DEFAULT_SHOWS";   