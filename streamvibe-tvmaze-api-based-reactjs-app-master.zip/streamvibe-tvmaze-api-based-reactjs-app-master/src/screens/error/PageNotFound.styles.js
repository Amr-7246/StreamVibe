import styled from "styled-components";

export const PageNotFoundWrap = styled.div`
  min-height: 100vh;

  .page-not-found-img {
    max-width: 400px;
  }
`;